#include<iostream>
using namespace std;

inline int cube(int s){
	return s*s*s;
	}

int main(){

	cout<<"Cube of the number is:"<<cube(5)<<endl;
	return 0;
}
