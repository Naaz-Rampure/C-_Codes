#include<iostream>
using namespace std;

class Calculater{
	public:
	int input1;
	int input2;
	void setInput(int a,int b){
	input1=a;
	input2=b;
}
	int add(Calculater obj1,Calculater obj2){
	return obj1.input1+obj2.input2;
}
};

int main(){

	Calculater obj1,obj2,obj3;
	obj1.setInput(10,2);
	obj2.setInput(5,5);
	cout<<"The input:"<<obj1.input1<<" "<<obj1.input2<<endl;
	cout<<"The sum of inputs is:"<<obj1.add(obj1,obj2);
	return 0;
}
