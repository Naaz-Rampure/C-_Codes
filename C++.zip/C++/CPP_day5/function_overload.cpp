#include<iostream>
using namespace std;

int sum(int x)
{
	return x;
}

int sum(float x,float y)
{
	return(x+y);
}

int sum(int x,int y,int z)
{
return x+y+z;
}

int sum(float x,float y,float z)
{
return x+y+z;
}


int main()
{
cout<<"Sum is:"<<sum(1)<<endl;
cout<<"sum is:"<<sum(3.56f,4.96f)<<endl;
cout<<"sum is:"<<sum(1,2,3)<<endl;
cout<<"sum is:"<<sum(1.56,2,3.5)<<endl;
}
