#include<iostream>
using namespace std;

class Box{
	double width;
	public:
	friend void printwidth(Box);
	void setwidth(double wid);
};
void Box::setwidth(double wid){
	width=wid;
}

void printwidth(Box b){
	cout<<"Width of box:"<<b.width;
}

int main(){
	Box box;
	box.setwidth(10.0);
	printwidth(box);
	return 0;
}
