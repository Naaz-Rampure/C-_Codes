#include<iostream>
#include<fstream>
#include<string>
using namespace std;

int main(){
	fstream word("data.txt");
	int count=0;
	string search="the";
	string temp;
	while(word>>temp){
		
		if(temp==search)
		{
			++count;
		}
	}
	cout<<count<<endl;

	return 0;
}


