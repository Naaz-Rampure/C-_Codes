#include<iostream>
#include<fstream>

using namespace std;

int main(){
	fstream fin("data1_word_A.txt");
	int word;
	char ch;

	fin.seekg(0,ios::beg);  //this will begin position of file pointer from start of file

	while(fin){
		fin.get(ch);
		if(ch =='a')
		word++;
	}
	
	cout<<"Word is:"<<word;
	return 0;
}

/*
#include<iostream>
#include<fstream>
using namespace std;

int main(){
	fstream fin("data1_word_A.txt");
	int count;
	char ch='a';
	char temp;
	while(fin>>temp){
		if(temp==ch){
			++count;
		}
}
	cout<<count;
return 0;
}

*/
