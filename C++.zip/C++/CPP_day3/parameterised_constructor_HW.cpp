#include<iostream>
using namespace std;

class Distance{
	int feet, inch;

	public:
	Distance(int a,int b){
		feet=a;
		inch=b;
		cout<<"Feet:"<<feet<<"Inch:"<<inch;
		}
	};

int main(){
	int a,b;

	cout<<"Enter feets and inches:";
	cin>>a>>b;
	Distance(a,b);
	return 0;
}
