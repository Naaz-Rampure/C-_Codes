#include<iostream>
using namespace std;

class Measure{
public:
float height,length,width;

void setinput(){
float h, l, w;
cout<<"\nEnter the height:";
cin>>h;
height=h;
cout<<"Enter the length:";
cin>>l;
length=l;
cout<<"Enter the width:";
cin>>w;
width=w;

}

int area(){
return length*width;
}

int volume(){
return height*length*width;
}
};

int main(){
Measure obj;
Measure obj1;

obj.setinput();
cout<<"\nThe input for area is:"<<obj.height<<" "<<obj.length<<" "<<obj.width<<endl;
cout<<"The Area is:"<<obj.area();

obj1.setinput();
cout<<"\nThe input for volume is:"<<obj1.height<<" "<<obj1.length<<" "<<obj1.width<<endl;
cout<<"The volume is:"<<obj1.volume();

return 0;
}


