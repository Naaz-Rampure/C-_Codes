#include<iostream>
using namespace std;

class Calculater{
	public:
	int input1;
	int input2;
	void setinput(int a,int b){
	input1=a;
	input2=b;
}
	int add(Calculater obj1,Calculater obj2){
	return obj1.input1+obj2.input2;
}

	int sub(Calculater obj1,Calculater obj2){
	return obj1.input1-obj2.input2;
}

	int mul(Calculater obj1,Calculater obj2){
	return obj1.input1*obj2.input2;
}

	int div(Calculater obj1,Calculater obj2){
	return obj1.input1/obj2.input2;
}
};

int main(){
	Calculater obj1,obj2,obj3;
	obj1.setinput(10,2);
	obj2.setinput(5,5);
	cout<<"The input:"<<obj1.input1<<" "<<obj1.input2<<endl;
	cout<<"The sum of inputs is:"<<obj1.add(obj1,obj2);
	cout<<"\n The sub of inputs is:"<<obj1.sub(obj1,obj2);
	cout<<"\nThe mul of inputs is:"<<obj1.mul(obj1,obj2);
	cout<<"\nThe div of inputs is:"<<obj1.div(obj1,obj2);
	return 0;
}
