#include<iostream>
#include<fstream>
#include<string>
using namespace std;

int main(){
	fstream fin("data4_end_S.txt");
	int count=0;
	char ch='s';
	string ch1;
	string temp;

	while(fin>>temp){
		for(int i=0;i<temp.length();i++)
			if(temp[i] == ch){
			count++;
			}
	}
	cout<<"word is:"<<count;
	return 0;
}


