#include<iostream>
using namespace std;

class Calculater{
	public:
	int input1;
	int input2;
	void setinput(int a,int b){
	input1=a;
	input2=b;
}

	Calculater add(Calculater obj1,Calculater obj2){
		Calculater obj3;
		obj3.input1=obj1.input1+obj2.input1;
		obj3.input1=obj1.input2+obj2.input2;
		return obj3;
}
};

int main(){
	Calculater obj1,obj2,obj3;
	obj1.setinput(10,2);
	obj2.setinput(5,5);
	obj3=obj1.add(obj1,obj2);
	cout<<"Results:"<<obj3.input1<<" " <<obj3.input2;
	return 0 ;
}
