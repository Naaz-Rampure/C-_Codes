#include<iostream>
using namespace std;

class Area{
	private:
	 int length,breath;
	public:
	Area(){
	length=5;
	breath=2;
	}
	void Calculater(){
		cout<<"\narea:"<<length*breath;
	}
};

int main(){
	Area A1;
	A1.Calculater();
	Area A2;
	A2.Calculater();
	return 0;
}

