#include<iostream>
#include<fstream>
#include<string>
#include<stdlib.h>
using namespace std;

class Student{
	private:
		int id;
		string name, branch,location;
	public:
		void menu();
		void insert_details();
		void find_stu();
	};

	void Student::menu(){
		int choice;
		char x;
		cout<<"Menu:";
		cout<<"\n1)Enter Student details.";
		cout<<"\n2) Find student.";

		cout<<"\nEnter your choice:";
		cin>>choice;
		switch(choice){
		case 1:
			do{
				insert_details();
				cout<<"\nAdd Another Student(y/n):";
				cin>>x;
			}while(x=='y'||x=='Y');
			break;
		case 2:
			find_stu();
			break;
		default:
			cout<<"Invalid choice";
			}
}
		
	void Student::insert_details(){
		fstream fin;
		cout<<"Enter the student ID:";
		cin>>id;
		cout<<"Enter the name:";
		cin>>name;
		cout<<"Enter your Branch:";
		cin>>branch;
		cout<<"Enter your location:";
		cin>>location;
		 fin.open("student_data.txt",ios::app|ios_base::out);
		fin<<" "<<id<<" "<<name<<" "<<branch<<" "<<location;
		fin.close();
	}


void Student::find_stu() // search data of student
{
    fstream file;
    int found = 0;
    int rollno; 
   file.open("student_data.txt", ios_base::in);
 	if(!file){
        
      cout << "\nNo Data is Present... " << endl;
    
}
    else
    {
        cout << "\nEnter Roll No. of Student which you want to search: ";
        cin >> rollno;
      
        while (!file.eof())
        {
            if (rollno == id)
            {
		 cout << "\nStudent ID.: " << id << "\n";
                cout << "Name: " << name << "\n";
                cout << "Branch: " << branch << "\n";
                cout << "Location: " << location << "\n";
               
                found++;
            }
            file >>id>>name>>branch>>location;
           
        }
        file.close();
	
    }
	if(rollno!=id)
	cout<<"No data fount";
}


int main(){
	
	Student s;
	s.menu();
	
}





