#include<iostream>
using namespace std;

class rectangle{
	int length,width;
	public:
	rectangle(){
		length=0;
		width=0;
	}
	rectangle(int x, int y){
	length=x;
	width=y;
	}

	rectangle(rectangle &_r){
	length=_r.length;
	width=_r.width;
	}
};

int main(){
	rectangle r1;
	rectangle r2(10,20);
	
	rectangle r3(r2);
	
}
