#include<iostream>
using namespace std;

class Marks{
public:
int maths;
int science;

Marks(){
	cout<<"Inside const:"<<endl;
	cout<<"c++ object"<<endl;
}

~Marks(){
	cout<<"Inside distructor:"<<endl;
	cout<<"C++ object destructed"<<endl;
}
};

int main(){
	Marks m1;
	Marks m2;
	return 0;
}
