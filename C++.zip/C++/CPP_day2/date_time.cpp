#include<iostream>
using namespace std;

class Time{
	int hour,min,sec;
	void setTime(){
	
