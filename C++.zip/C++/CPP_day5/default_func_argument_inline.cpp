#include<iostream>
using namespace std;

int cubevolume(int l=5,int w=6,int h=7)
{
	return l*w*h;
}

int main(){
cout<<"volume:"<<cubevolume()<<endl;
cout<<"cubevolume:"<<cubevolume(9)<<endl;
cout<<"cubevolume:"<<cubevolume(15,2)<<endl;
cout<<"cubevolume:"<<cubevolume(3,4,5)<<endl;
}
/*


#include<iostream>
using namespace std;

int sum(int x=5,int y=6,int z=7)
{
	return x+y+z;
}

int main(){
cout<<"sum is:"<<
return 0;
}
*/
